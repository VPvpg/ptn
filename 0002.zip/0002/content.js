﻿function blockAds() {
  // Находим все рекламные элементы на странице
  var ads = document.querySelectorAll('iframe, object, embed, [onclick*="adserver"], [href*="ad."], [src*="ad."], [src*="ads/"]');

  // Скрываем или удаляем рекламные элементы
  for (var i = 0; i < ads.length; i++) {
    ads[i].style.display = 'none';
    // или
    // ads[i].parentNode.removeChild(ads[i]);
  }
}

// Запускаем функцию блокировки рекламы при загрузке страницы
window.addEventListener('load', blockAds);